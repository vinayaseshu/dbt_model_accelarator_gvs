# dbt accelerator v2.1.0 - generation report

Mapping: `STM_dbt_Mapping_Template.xlsx`  
Features: Staging default=on, Model contracts=off, Surrogate keys=off, Audit columns=off, Source freshness=off

## Models

| Model | Status | Folder | Materialization | Unique key | Staging | Contract | Upstream | Issues |
|---|---|---|---|---|---|---|---|---|
| emp_target | OK | marts/hr | table | empno | yes | no | stg_hr__emp | - |
| dept_target | OK | marts/hr | table | deptno | yes | no | stg_hr__dept | - |
| emp_dept_target | OK | marts/hr | table | empno, deptno | yes | no | stg_hr__emp, stg_hr__dept | - |
| emp_incr | OK | marts/hr | incremental | empno | yes | no | stg_hr__emp | - |

## Sources

| Source | Table | Staging model | Columns used |
|---|---|---|---|
| hr | emp | stg_hr__emp | empno, ename, deptno, updated_at |
| hr | dept | stg_hr__dept | deptno, dname |
